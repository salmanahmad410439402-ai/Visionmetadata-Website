const fs = require('fs-extra');
const path = require('path');
const JavaScriptObfuscator = require('javascript-obfuscator');

const SOURCE_DIR = __dirname;
const BUILD_DIR = path.join(__dirname, 'dist-obfuscated');

// The files we want to obfuscate to protect the extension
const JS_FILES_TO_OBFUSCATE = [
    'background.js',
    'popup.js',
    'content.js'
];

async function build() {
    console.log('Starting obfuscation build process...');

    // Clean previous build
    if (fs.existsSync(BUILD_DIR)) {
        fs.removeSync(BUILD_DIR);
    }
    fs.mkdirSync(BUILD_DIR);

    // Copy everything over first (HTML, CSS, images, manifest)
    console.log('Copying assets...');
    fs.readdirSync(SOURCE_DIR).forEach(file => {
        // Skip node_modules, dist, package files, and build.js
        if (['node_modules', 'dist-obfuscated', 'package.json', 'package-lock.json', 'build.js'].includes(file)) return;
        
        const srcPath = path.join(SOURCE_DIR, file);
        const destPath = path.join(BUILD_DIR, file);
        fs.copySync(srcPath, destPath);
    });

    // Now obfuscate the JS files
    console.log('Obfuscating JavaScript files for security...');
    for (const file of JS_FILES_TO_OBFUSCATE) {
        const filePath = path.join(BUILD_DIR, file);
        if (fs.existsSync(filePath)) {
            console.log(`Obfuscating: ${file}`);
            const code = fs.readFileSync(filePath, 'utf8');
            
            // Heavy obfuscation settings to make it extremely difficult to reverse-engineer
            const obfuscationResult = JavaScriptObfuscator.obfuscate(code, {
                compact: true,
                controlFlowFlattening: true,
                controlFlowFlatteningThreshold: 1,
                deadCodeInjection: true,
                deadCodeInjectionThreshold: 0.4,
                debugProtection: false,
                debugProtectionInterval: 0,
                disableConsoleOutput: false,
                identifierNamesGenerator: 'hexadecimal',
                log: false,
                numbersToExpressions: true,
                renameGlobals: false,
                selfDefending: true,
                simplify: true,
                splitStrings: true,
                splitStringsChunkLength: 10,
                stringArray: true,
                stringArrayCallsTransform: true,
                stringArrayCallsTransformThreshold: 1,
                stringArrayEncoding: ['base64'],
                stringArrayIndexShift: true,
                stringArrayRotate: true,
                stringArrayShuffle: true,
                stringArrayWrappersCount: 5,
                stringArrayWrappersChainedCalls: true,
                stringArrayWrappersParametersMaxCount: 5,
                stringArrayWrappersType: 'function',
                stringArrayThreshold: 1,
                transformObjectKeys: true,
                unicodeEscapeSequence: false
            });

            fs.writeFileSync(filePath, obfuscationResult.getObfuscatedCode());
        }
    }

    console.log('Build completed successfully!');
    console.log(`Your protected extension is now available in the '${BUILD_DIR}' folder.`);
}

build().catch(console.error);
