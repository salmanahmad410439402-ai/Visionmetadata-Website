-- 1. Create the licenses table
CREATE TABLE licenses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'active', -- 'active' or 'inactive'/revoked
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    started_at TIMESTAMP WITH TIME ZONE,
    ends_at TIMESTAMP WITH TIME ZONE,
    last_used_at TIMESTAMP WITH TIME ZONE
);

-- 2. Create the verify_license RPC function
-- This function checks if the key exists, activates it if not yet started, and validates the dates
CREATE OR REPLACE FUNCTION verify_license(license_key TEXT)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    found_license RECORD;
    duration_str TEXT;
    duration_interval INTERVAL;
BEGIN
    -- Look for the license key
    SELECT * INTO found_license
    FROM licenses
    WHERE key = license_key;

    -- If no key is found
    IF NOT FOUND THEN
        RETURN json_build_object('valid', false, 'message', 'Invalid license key.');
    END IF;

    -- If key is found but not active
    IF found_license.status != 'active' THEN
        RETURN json_build_object('valid', false, 'message', 'This license key has been deactivated.');
    END IF;

    -- If the license hasn't been activated yet, set started_at and calculate ends_at
    IF found_license.started_at IS NULL THEN
        -- Extract the duration from the end of the key (e.g., '1M' from 'VM-PRO-GAF646A5-1M')
        duration_str := split_part(license_key, '-', 4);
        
        IF duration_str = '1M' THEN
            duration_interval := interval '1 month';
        ELSIF duration_str = '3M' THEN
            duration_interval := interval '3 months';
        ELSIF duration_str = '6M' THEN
            duration_interval := interval '6 months';
        ELSIF duration_str = '1Y' THEN
            duration_interval := interval '1 year';
        ELSE
            -- Default or fallback if format is unexpected
            duration_interval := interval '1 month'; 
        END IF;

        -- Update the record with activation dates
        UPDATE licenses
        SET started_at = NOW(),
            ends_at = NOW() + duration_interval,
            last_used_at = NOW()
        WHERE key = license_key
        RETURNING * INTO found_license;
    ELSE
        -- If already activated, check if it has expired
        IF NOW() > found_license.ends_at THEN
            RETURN json_build_object('valid', false, 'message', 'This license key has expired.', 'expired_on', found_license.ends_at);
        END IF;
        
        -- Update last used time
        UPDATE licenses
        SET last_used_at = NOW()
        WHERE key = license_key;
    END IF;

    -- Return success with dates
    RETURN json_build_object(
        'valid', true, 
        'message', 'License is valid.', 
        'status', found_license.status,
        'started_at', found_license.started_at,
        'ends_at', found_license.ends_at
    );
END;
$$;
